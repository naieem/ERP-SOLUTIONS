(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["packages-login-login-module"],{

/***/ "./src/app/packages/login/login.module.ts":
/*!************************************************!*\
  !*** ./src/app/packages/login/login.module.ts ***!
  \************************************************/
/*! exports provided: LoginModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginModule", function() { return LoginModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/input */ "./node_modules/@angular/material/esm5/input.es5.js");
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/form-field */ "./node_modules/@angular/material/esm5/form-field.es5.js");
/* harmony import */ var angulartics2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angulartics2 */ "./node_modules/angulartics2/fesm5/angulartics2.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/esm5/button.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./login/login.component */ "./src/app/packages/login/login/login.component.ts");
/* harmony import */ var _register_register_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./register/register.component */ "./src/app/packages/login/register/register.component.ts");












var routes = [
    {
        path: '',
        component: _login_login_component__WEBPACK_IMPORTED_MODULE_10__["LoginComponent"],
    },
    {
        path: 'register',
        component: _register_register_component__WEBPACK_IMPORTED_MODULE_11__["RegisterComponent"]
    }
];
var LoginModule = /** @class */ (function () {
    function LoginModule() {
    }
    LoginModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_login_login_component__WEBPACK_IMPORTED_MODULE_10__["LoginComponent"], _register_register_component__WEBPACK_IMPORTED_MODULE_11__["RegisterComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__["FlexLayoutModule"],
                _angular_material_input__WEBPACK_IMPORTED_MODULE_5__["MatInputModule"],
                _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__["MatFormFieldModule"],
                _angular_material_button__WEBPACK_IMPORTED_MODULE_8__["MatButtonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
                angulartics2__WEBPACK_IMPORTED_MODULE_7__["Angulartics2Module"],
                _angular_router__WEBPACK_IMPORTED_MODULE_9__["RouterModule"].forChild(routes)
            ]
        })
    ], LoginModule);
    return LoginModule;
}());



/***/ }),

/***/ "./src/app/packages/login/login/login.component.html":
/*!***********************************************************!*\
  !*** ./src/app/packages/login/login/login.component.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"loginContainer\">\n    <div class=\"login_bg\" fxFlex>\n        <div fxFlex=\"80\" fxHide.xs fxFlex.sm=\"70\">\n            &nbsp;\n        </div>\n        <div fxFlex=\"20\" fxFlex.xs=\"100\" fxFlex.sm=\"30\" class=\"loginFormContainer\" fxLayout=\"column\">\n            <div fxFlex=\"35\" class=\"logoContainer\" fxLayoutAlign=\"center center\">\n                <img src=\"https://tbncdn.freelogodesign.org/3d67aac7-f819-41a9-b0f6-75095b8fb712.png?1547445612256\">\n            </div>\n            <div fxFlex class=\"loginFormContainer\">\n                <form [formGroup]=\"loginForm\" fxFlex fxLayoutAlign=\"strech center\" (ngSubmit)=\"onSubmit()\" fxLayout=\"column\">\n                    <h2>Login</h2>\n                    <!-- login form -->\n                    <div fxFlex fxLayout=\"column\" class=\"input-container\">\n                        <mat-form-field class=\"w-100-p\">\n                            <input matInput placeholder=\"Email\" color=\"warn\" formControlName=\"email\" value=\"\">\n                        </mat-form-field>\n                        <mat-form-field class=\"w-100-p\">\n                            <input matInput placeholder=\"Password\" type=\"password\" formControlName=\"password\" value=\"\">\n                        </mat-form-field>\n                        <button mat-raised-button color=\"warn\" style=\"margin-top:20px;\">Login</button>\n                        <div style=\"margin-top:20px;\" fxLayoutAlign=\"center stretch\">\n                            <a href=\"#\" (click)=\"showRegisterForm($event)\">Register</a>\n                        </div>\n                    </div>\n                </form>\n            </div>\n        </div>\n    </div>\n</div>"

/***/ }),

/***/ "./src/app/packages/login/login/login.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/packages/login/login/login.component.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".loginContainer {\n  height: 100%; }\n  .loginContainer .login_bg {\n    background-image: url(\"https://images.unsplash.com/photo-1536982942848-09777d0cd8f0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2134&q=80\");\n    background-position: center center;\n    background-size: cover; }\n  .loginContainer .login_bg .loginFormContainer {\n      background-color: #fff; }\n  .loginContainer .login_bg .logoContainer {\n      padding-top: 40px; }\n  .loginContainer .login_bg .input-container {\n      padding: 0 20px;\n      width: 95%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFja2FnZXMvbG9naW4vbG9naW4vRDpcXHdvcmtcXFByb2plY3RzXFxhbmd1bGFyMlxcYW5ndWxhci1tYXRlcmlhbC9zcmNcXGFwcFxccGFja2FnZXNcXGxvZ2luXFxsb2dpblxcbG9naW4uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFZLEVBZ0JmO0VBakJEO0lBR1EsZ0tBQStKO0lBQy9KLG1DQUFrQztJQUNsQyx1QkFBc0IsRUFXekI7RUFoQkw7TUFPWSx1QkFBc0IsRUFDekI7RUFSVDtNQVVZLGtCQUFpQixFQUNwQjtFQVhUO01BYVksZ0JBQWU7TUFDZixXQUFVLEVBQ2IiLCJmaWxlIjoic3JjL2FwcC9wYWNrYWdlcy9sb2dpbi9sb2dpbi9sb2dpbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sb2dpbkNvbnRhaW5lciB7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAubG9naW5fYmcge1xyXG4gICAgICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1MzY5ODI5NDI4NDgtMDk3NzdkMGNkOGYwP2l4bGliPXJiLTEuMi4xJml4aWQ9ZXlKaGNIQmZhV1FpT2pFeU1EZDkmYXV0bz1mb3JtYXQmZml0PWNyb3Amdz0yMTM0JnE9ODAnKTtcclxuICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xyXG4gICAgICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICAgICAgLmxvZ2luRm9ybUNvbnRhaW5lciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5sb2dvQ29udGFpbmVyIHtcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6IDQwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5pbnB1dC1jb250YWluZXIge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwIDIwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiA5NSU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */"

/***/ }),

/***/ "./src/app/packages/login/login/login.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/packages/login/login/login.component.ts ***!
  \*********************************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var angulartics2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! angulartics2 */ "./node_modules/angulartics2/fesm5/angulartics2.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _core_services_core_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../core/services/core.service */ "./src/app/packages/core/services/core.service.ts");







var LoginComponent = /** @class */ (function () {
    function LoginComponent(fb, coreService, router, angulartics2) {
        this.fb = fb;
        this.coreService = coreService;
        this.router = router;
        this.angulartics2 = angulartics2;
        this.loginForm = this
            .fb
            .group({
            email: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required
            ],
            password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
    }
    LoginComponent.prototype.ngOnInit = function () {
        var isUserLoggedIn = this
            .coreService
            .getLoggedInUserStatus();
        if (isUserLoggedIn) {
            this
                .coreService
                .showSidenavToolbar();
            this
                .router
                .navigate(["/"]);
        }
        else {
            this
                .coreService
                .hideSideNavToolbar();
        }
    };
    LoginComponent.prototype.onSubmit = function () {
        var _this = this;
        firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]()
            .signInWithEmailAndPassword(this.loginForm.value.email, this.loginForm.value.password)
            .then(function (userinfo) {
            console.log(userinfo);
            debugger;
            // if(window && window['ga']){   window['ga']('send', {     hitType: 'event',
            //  eventCategory: 'My Category',     eventAction: 'My Action',     eventLabel:
            // 'My Label',     dimension1: 'the value for my dimension'   }); }
            _this
                .angulartics2
                .eventTrack
                .next({
                action: 'UserLogin',
                properties: {
                    label: userinfo.user.email + ' logged in',
                    category: 'UserLogin',
                    dimension1: userinfo.user.email + ' logged in'
                }
            });
            firebase__WEBPACK_IMPORTED_MODULE_5__["auth"]()
                .currentUser
                .getIdToken()
                .then(function (idToken) {
                debugger;
                localStorage.setItem('accessToken', idToken);
            })
                .catch(function (error) {
                console.log('error found in login submit call');
                console.log(error);
            });
            if (userinfo) {
                _this
                    .coreService
                    .showSidenavToolbar();
                _this
                    .coreService
                    .setUserLoggedInStatus(true);
                _this
                    .router
                    .navigate(['/']);
            }
        })
            .catch(function (error) {
            var errorCode = error.code;
            var errorMessage = error.message;
            if (errorCode === 'auth/wrong-password') {
                alert('Wrong password.');
            }
            else {
                alert(errorMessage);
            }
            console.log(error);
        });
    };
    LoginComponent.prototype.showRegisterForm = function (event) {
        event.preventDefault();
        event.stopPropagation();
        this
            .router
            .navigate(['./login/register']);
    };
    LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({ selector: 'app-login', template: __webpack_require__(/*! ./login.component.html */ "./src/app/packages/login/login/login.component.html"), styles: [__webpack_require__(/*! ./login.component.scss */ "./src/app/packages/login/login/login.component.scss")] }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _core_services_core_service__WEBPACK_IMPORTED_MODULE_6__["CoreService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], angulartics2__WEBPACK_IMPORTED_MODULE_4__["Angulartics2"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/packages/login/register/register.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/packages/login/register/register.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"registerContainer\">\n    <div class=\"register_bg\" fxFlex fxLayoutAlign=\"center stretch\">\n        <div fxFlex=\"50\" fxFlex.xs=\"100\" fxFlex.sm=\"50\" class=\"registerFormContainer\" fxLayout=\"column\">\n            <div fxFlex=\"35\" class=\"logoContainer\" fxLayoutAlign=\"center center\">\n                <img src=\"https://tbncdn.freelogodesign.org/3d67aac7-f819-41a9-b0f6-75095b8fb712.png?1547445612256\">\n            </div>\n            <div fxFlex class=\"registerFormContainer\">\n                <form [formGroup]=\"registerForm\" fxFlex fxLayoutAlign=\"strech center\" (ngSubmit)=\"onSubmit()\" fxLayout=\"column\">\n                    <h2>Registrer</h2>\n                    <!-- registration form -->\n                    <div fxFlex fxLayout=\"column\" class=\"input-container\" fxLayoutAlign=\"center center\">\n                        <mat-form-field class=\"w-100-p\">\n                            <input matInput color=\"warn\" placeholder=\"Email:\" formControlName=\"email\" value=\"\">\n                        </mat-form-field>\n                        <mat-form-field class=\"w-100-p\">\n                            <input matInput color=\"warn\" placeholder=\"Firstname:\" formControlName=\"fname\" value=\"\">\n                        </mat-form-field>\n                        <mat-form-field class=\"w-100-p\">\n                            <input matInput color=\"warn\" placeholder=\"Lastname:\" formControlName=\"lname\" value=\"\">\n                        </mat-form-field>\n                        <mat-form-field class=\"w-100-p\">\n                            <input matInput color=\"warn\" placeholder=\"Address:\" formControlName=\"address\" value=\"\">\n                        </mat-form-field>\n                        <mat-form-field class=\"w-100-p\">\n                            <input matInput placeholder=\"Password:\" type=\"password\" formControlName=\"password\" value=\"\">\n                        </mat-form-field>\n                        <mat-form-field class=\"w-100-p\">\n                            <input matInput placeholder=\"Confirm Password:\" type=\"password\" formControlName=\"cpassword\" value=\"\">\n                        </mat-form-field>\n                        <button mat-raised-button color=\"warn\" style=\"margin-top:20px;\">Register</button>\n                        <div style=\"margin-top:20px;\">\n                            <a href=\"#\" (click)=\"showLoginForm($event)\">Login</a>\n                        </div>\n                    </div>\n                </form>\n            </div>\n        </div>\n    </div>\n</div>"

/***/ }),

/***/ "./src/app/packages/login/register/register.component.scss":
/*!*****************************************************************!*\
  !*** ./src/app/packages/login/register/register.component.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".registerContainer {\n  height: 100%; }\n  .registerContainer .register_bg {\n    background-image: url(\"https://images.unsplash.com/photo-1536982942848-09777d0cd8f0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2134&q=80\");\n    background-position: center center;\n    background-size: cover; }\n  .registerContainer .register_bg .registerFormContainer {\n      background-color: #fff; }\n  .registerContainer .register_bg .logoContainer {\n      padding-top: 40px; }\n  .registerContainer .register_bg .input-container {\n      padding: 0 20px;\n      width: 95%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFja2FnZXMvbG9naW4vcmVnaXN0ZXIvRDpcXHdvcmtcXFByb2plY3RzXFxhbmd1bGFyMlxcYW5ndWxhci1tYXRlcmlhbC9zcmNcXGFwcFxccGFja2FnZXNcXGxvZ2luXFxyZWdpc3RlclxccmVnaXN0ZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFZLEVBZ0JmO0VBakJEO0lBR1EsZ0tBQStKO0lBQy9KLG1DQUFrQztJQUNsQyx1QkFBc0IsRUFXekI7RUFoQkw7TUFPWSx1QkFBc0IsRUFDekI7RUFSVDtNQVVZLGtCQUFpQixFQUNwQjtFQVhUO01BYVksZ0JBQWU7TUFDZixXQUFVLEVBQ2IiLCJmaWxlIjoic3JjL2FwcC9wYWNrYWdlcy9sb2dpbi9yZWdpc3Rlci9yZWdpc3Rlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZWdpc3RlckNvbnRhaW5lciB7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAucmVnaXN0ZXJfYmcge1xyXG4gICAgICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1MzY5ODI5NDI4NDgtMDk3NzdkMGNkOGYwP2l4bGliPXJiLTEuMi4xJml4aWQ9ZXlKaGNIQmZhV1FpT2pFeU1EZDkmYXV0bz1mb3JtYXQmZml0PWNyb3Amdz0yMTM0JnE9ODAnKTtcclxuICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xyXG4gICAgICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICAgICAgLnJlZ2lzdGVyRm9ybUNvbnRhaW5lciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5sb2dvQ29udGFpbmVyIHtcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6IDQwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5pbnB1dC1jb250YWluZXIge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwIDIwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiA5NSU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */"

/***/ }),

/***/ "./src/app/packages/login/register/register.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/packages/login/register/register.component.ts ***!
  \***************************************************************/
/*! exports provided: RegisterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterComponent", function() { return RegisterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _core_services_core_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../core/services/core.service */ "./src/app/packages/core/services/core.service.ts");





var RegisterComponent = /** @class */ (function () {
    function RegisterComponent(fb, coreService, router) {
        this.fb = fb;
        this.coreService = coreService;
        this.router = router;
        this.registerForm = this
            .fb
            .group({
            email: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required
            ],
            fname: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required
            ],
            lname: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required
            ],
            address: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required
            ],
            password: [
                '', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required
            ],
            cpassword: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
    }
    RegisterComponent.prototype.ngOnInit = function () {
        var isUserLoggedIn = this
            .coreService
            .getLoggedInUserStatus();
        if (isUserLoggedIn) {
            this
                .coreService
                .showSidenavToolbar();
            this
                .router
                .navigate(["/"]);
        }
        else {
            this
                .coreService
                .hideSideNavToolbar();
        }
    };
    RegisterComponent.prototype.showLoginForm = function (event) {
        event.preventDefault();
        event.stopPropagation();
        this
            .router
            .navigate(['/login']);
    };
    RegisterComponent.prototype.onSubmit = function () {
        console.log(this.registerForm.value);
    };
    RegisterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({ selector: 'app-register', template: __webpack_require__(/*! ./register.component.html */ "./src/app/packages/login/register/register.component.html"), styles: [__webpack_require__(/*! ./register.component.scss */ "./src/app/packages/login/register/register.component.scss")] }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _core_services_core_service__WEBPACK_IMPORTED_MODULE_4__["CoreService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], RegisterComponent);
    return RegisterComponent;
}());



/***/ })

}]);
//# sourceMappingURL=packages-login-login-module.js.map