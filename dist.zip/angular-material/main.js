(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./business/about/about.module": [
		"./src/app/business/about/about.module.ts",
		"business-about-about-module"
	],
	"./business/contact/contact.module": [
		"./src/app/business/contact/contact.module.ts",
		"business-contact-contact-module"
	],
	"./business/home/home.module": [
		"./src/app/business/home/home.module.ts",
		"business-home-home-module"
	],
	"./packages/login/login.module": [
		"./src/app/packages/login/login.module.ts",
		"packages-login-login-module"
	],
	"./packages/page-not-found/page-not-found.module": [
		"./src/app/packages/page-not-found/page-not-found.module.ts",
		"packages-page-not-found-page-not-found-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return __webpack_require__.e(ids[1]).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./routes */ "./src/app/routes.ts");




var appRoutes = _routes__WEBPACK_IMPORTED_MODULE_3__["SiteRoute"];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(appRoutes, { enableTracing: false })],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"app-{{currentTheme}}-theme\">\r\n    <mat-sidenav-container class=\"container\">\r\n        <mat-sidenav #sidenav class=\"bottom-to-top sidenav-container\" [(mode)]=\"over\" [(opened)]=\"opened\" *ngIf=\"!hideSidenavToolbar\">\r\n            <app-sidebar></app-sidebar>\r\n        </mat-sidenav>\r\n\r\n        <mat-sidenav-content>\r\n            <app-toolbar [sidenav]=\"sidenav\" *ngIf=\"!hideSidenavToolbar\"></app-toolbar>\r\n            <div class=\"mainContainer\">\r\n                <router-outlet></router-outlet>\r\n            </div>\r\n        </mat-sidenav-content>\r\n    </mat-sidenav-container>\r\n</div>"

/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var angulartics2_ga__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! angulartics2/ga */ "./node_modules/angulartics2/ga/fesm5/angulartics2-ga.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _packages_guard_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./packages/guard/auth.service */ "./src/app/packages/guard/auth.service.ts");
/* harmony import */ var _packages_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./packages/core */ "./src/app/packages/core/index.ts");







var AppComponent = /** @class */ (function () {
    function AppComponent(media, angulartics2GoogleAnalytics, authService, coreService, router) {
        var _this = this;
        this.authService = authService;
        this.coreService = coreService;
        this.router = router;
        this.hideSidenavToolbar = true;
        this.opened = true;
        this.over = 'side';
        this.expandHeight = '42px';
        this.collapseHeight = '42px';
        this.displayMode = 'flat';
        this.currentTheme = 'pink';
        angulartics2GoogleAnalytics.startTracking();
        this.watcher = media.subscribe(function (change) {
            if (change.mqAlias === 'sm' || change.mqAlias === 'xs') {
                _this.opened = false;
                _this.over = 'push';
            }
            else {
                _this.over = 'side';
            }
        });
        this
            .coreService
            .changeTheme
            .subscribe(function (themeName) {
            _this.currentTheme = themeName;
        });
        // show/hiding toolbar and sidenav
        this
            .coreService
            .changeSideNavToolbarStatus
            .subscribe(function (result) {
            debugger;
            _this.hideSidenavToolbar = result;
        });
    }
    AppComponent.prototype.ngOnInit = function () {
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({ selector: 'app-root', template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"), styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")] }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_flex_layout__WEBPACK_IMPORTED_MODULE_2__["ObservableMedia"], angulartics2_ga__WEBPACK_IMPORTED_MODULE_3__["Angulartics2GoogleAnalytics"], _packages_guard_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"], _packages_core__WEBPACK_IMPORTED_MODULE_6__["CoreService"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var angulartics2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! angulartics2 */ "./node_modules/angulartics2/fesm5/angulartics2.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _packages_sidebar_sidebar_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./packages/sidebar/sidebar.module */ "./src/app/packages/sidebar/sidebar.module.ts");
/* harmony import */ var _packages_toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./packages/toolbar/toolbar.module */ "./src/app/packages/toolbar/toolbar.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_12__);













var config = {
    apiKey: "AIzaSyDGTLXyAMD-E-EEx064vpGD5KFmilLe5yc",
    authDomain: "ionic2-test-cb300.firebaseapp.com",
    databaseURL: "https://ionic2-test-cb300.firebaseio.com",
    projectId: "ionic2-test-cb300",
    storageBucket: "ionic2-test-cb300.appspot.com",
    messagingSenderId: "888777950862"
};
firebase__WEBPACK_IMPORTED_MODULE_12__["initializeApp"](config);
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_10__["AppComponent"],
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatCheckboxModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatToolbarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatMenuModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatFormFieldModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatSidenavModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_7__["FlexLayoutModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatExpansionModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatCardModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__["BrowserAnimationsModule"],
                _packages_sidebar_sidebar_module__WEBPACK_IMPORTED_MODULE_8__["default"],
                _packages_toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_9__["default"],
                _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_11__["AppRoutingModule"],
                angulartics2__WEBPACK_IMPORTED_MODULE_5__["Angulartics2Module"].forRoot(),
            ],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_10__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/navigations.ts":
/*!********************************!*\
  !*** ./src/app/navigations.ts ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var navigations = [
    {
        id: 'Home',
        title: 'Home',
        IsVisible: true,
        path: '/'
    },
    {
        id: 'About',
        title: 'About',
        IsVisible: true,
        path: '/about',
        children: [
            {
                id: 'Contact',
                title: 'Contact',
                path: '/contact'
            }
        ]
    },
    {
        id: 'Contact',
        title: 'Contact',
        IsVisible: true,
        path: '/contact',
        children: [
            {
                id: 'Contact',
                title: 'Contact',
                path: '/contact'
            }
        ]
    },
    {
        id: 'Home',
        title: 'List',
        IsVisible: true,
        path: '/list',
    }
];
/* harmony default export */ __webpack_exports__["default"] = (navigations);


/***/ }),

/***/ "./src/app/packages/core/index.ts":
/*!****************************************!*\
  !*** ./src/app/packages/core/index.ts ***!
  \****************************************/
/*! exports provided: CoreService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _services_core_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./services/core.service */ "./src/app/packages/core/services/core.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CoreService", function() { return _services_core_service__WEBPACK_IMPORTED_MODULE_0__["CoreService"]; });




/***/ }),

/***/ "./src/app/packages/core/services/core.service.ts":
/*!********************************************************!*\
  !*** ./src/app/packages/core/services/core.service.ts ***!
  \********************************************************/
/*! exports provided: CoreService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreService", function() { return CoreService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _guard_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../guard/auth.service */ "./src/app/packages/guard/auth.service.ts");
/* harmony import */ var _navigations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../navigations */ "./src/app/navigations.ts");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../routes */ "./src/app/routes.ts");





var CoreService = /** @class */ (function () {
    function CoreService(authService) {
        var _this = this;
        this.authService = authService;
        this.changeTheme = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.changeSideNavToolbarStatus = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.authService.onUserLoggedInStatusChange.subscribe(function (status) {
            debugger;
            if (status) {
                _this.showSidenavToolbar();
            }
            else {
                _this.hideSideNavToolbar();
            }
        });
    }
    CoreService.prototype.getRouteConfig = function () {
        return _routes__WEBPACK_IMPORTED_MODULE_4__["SiteRoute"];
    };
    CoreService.prototype.getVisibleRoutes = function () {
        var routes = [];
        _navigations__WEBPACK_IMPORTED_MODULE_3__["default"].map(function (value, index) {
            // console.log(value);
            if (value.IsVisible) {
                routes.push(value);
            }
        });
        return routes;
    };
    CoreService.prototype.hideSideNavToolbar = function () {
        this.hideSidenav = true;
        this.hideToolbar = true;
        this.setUserLoggedInStatus(false);
        this.changeSideNavToolbarStatus.emit(true);
    };
    CoreService.prototype.showSidenavToolbar = function () {
        this.hideSidenav = false;
        this.hideToolbar = false;
        this.setUserLoggedInStatus(true);
        this.changeSideNavToolbarStatus.emit(false);
    };
    CoreService.prototype.setUserLoggedInStatus = function (status) {
        this.isLoggedIn = status;
    };
    CoreService.prototype.getLoggedInUserStatus = function () {
        return this.isLoggedIn;
    };
    CoreService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({ providedIn: 'root' }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_guard_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]])
    ], CoreService);
    return CoreService;
}());



/***/ }),

/***/ "./src/app/packages/guard/auth.guard.ts":
/*!**********************************************!*\
  !*** ./src/app/packages/guard/auth.guard.ts ***!
  \**********************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.service */ "./src/app/packages/guard/auth.service.ts");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_4__);





var AuthGuard = /** @class */ (function () {
    function AuthGuard(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    AuthGuard.prototype.canActivate = function (route, state) {
        var _this = this;
        debugger;
        var url = state.url;
        return this
            .checkLogin(route)
            .then(function (status) {
            debugger;
            if (!status) {
                _this
                    .router
                    .navigate(['/login']);
            }
            return status;
        });
    };
    AuthGuard.prototype.canActivateChild = function (route, state) {
        return this
            .authService
            .IsUserLoggedIn();
    };
    AuthGuard.prototype.canLoad = function (route) {
        var url = "/" + route.path;
        debugger;
        var isUserLoggedIn = this
            .authService
            .IsUserLoggedIn();
        // location.href = '/login';
        return false;
    };
    AuthGuard.prototype.checkLogin = function (route) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            firebase__WEBPACK_IMPORTED_MODULE_4__["auth"]()
                .onAuthStateChanged(function (info) {
                debugger;
                if (info) {
                    resolve(_this.reRouteOnAuthSUccess(route));
                }
                else {
                    resolve(_this.reRouteOnAuthFailed(route));
                }
            });
        });
    };
    AuthGuard.prototype.reRouteOnAuthSUccess = function (route) {
        this
            .authService
            .setUserLoggedInUserStatus(true);
        if (route.routeConfig.path == 'login') {
            this
                .router
                .navigate(['/']);
            return true;
        }
        else {
            return true;
        }
    };
    AuthGuard.prototype.reRouteOnAuthFailed = function (route) {
        if (route.routeConfig.path == 'login') {
            this
                .authService
                .setUserLoggedInUserStatus(false);
            return true;
        }
        else {
            return false;
        }
    };
    AuthGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({ providedIn: 'root' }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], AuthGuard);
    return AuthGuard;
}());



/***/ }),

/***/ "./src/app/packages/guard/auth.service.ts":
/*!************************************************!*\
  !*** ./src/app/packages/guard/auth.service.ts ***!
  \************************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AuthService = /** @class */ (function () {
    function AuthService() {
        this.onUserLoggedInStatusChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    AuthService.prototype.setUserLoggedInUserStatus = function (status) {
        this.isUserLoggedIn = status;
        this.onUserLoggedInStatusChange.emit(status);
    };
    AuthService.prototype.IsUserLoggedIn = function () {
        return this.isUserLoggedIn;
    };
    AuthService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/packages/sidebar/sidebar.module.ts":
/*!****************************************************!*\
  !*** ./src/app/packages/sidebar/sidebar.module.ts ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sidebar/sidebar.component */ "./src/app/packages/sidebar/sidebar/sidebar.component.ts");







var SidebarModule = /** @class */ (function () {
    function SidebarModule() {
    }
    SidebarModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_6__["SidebarComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatCheckboxModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatToolbarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatMenuModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatSidenavModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__["FlexLayoutModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatExpansionModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatListModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatCardModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"]
            ],
            exports: [_sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_6__["SidebarComponent"]]
        })
    ], SidebarModule);
    return SidebarModule;
}());
/* harmony default export */ __webpack_exports__["default"] = (SidebarModule);


/***/ }),

/***/ "./src/app/packages/sidebar/sidebar/sidebar.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/packages/sidebar/sidebar/sidebar.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"profile_image_container\" fxLayoutAlign=\"center center\" fxLayoutGap=\"10px\">\n    <div class=\"with-bg\"></div>\n    <div>\n        <a>\n            <img class=\"circle\" src=\"https://picsum.photos/200/200/?image=575\" width=\"100\">\n        </a>\n    </div>\n</div>\n<div class=\"mt-2 profile_information_container\" fxLayout=\"column\" fxLayoutAlign=\"center center\" fxLayoutGap=\"7px\">\n    <div>\n        <a>\n            <span class=\"lead\">Rexford</span>\n        </a>\n    </div>\n    <div>\n        <a>\n            <span class=\"\">hello@khophi.co</span>\n        </a>\n    </div>\n</div>\n<div class=\"mt-3\">\n    <mat-nav-list>\n        <div *ngFor=\"let navigation of navigations\">\n            <div *ngIf=\"!navigation.children\">\n                <a mat-list-item class=\"text-center\" [routerLink]=\"navigation.path\">{{navigation.title}}</a>\n            </div>\n            <div *ngIf=\"navigation.children && navigation.children.length\">\n                <mat-accordion>\n                    <mat-expansion-panel (opened)=\"panelOpenState = true\" (closed)=\"panelOpenState = false\">\n                        <mat-expansion-panel-header>\n                            <mat-panel-title>\n                                {{navigation.title}}\n                            </mat-panel-title>\n                        </mat-expansion-panel-header>\n                        <a mat-list-item class=\"text-center\" *ngFor=\"let childNav of navigation.children\" [routerLink]=\"childNav.path\">{{childNav.title}}</a>\n                    </mat-expansion-panel>\n                </mat-accordion>\n            </div>\n        </div>\n    </mat-nav-list>\n</div>"

/***/ }),

/***/ "./src/app/packages/sidebar/sidebar/sidebar.component.scss":
/*!*****************************************************************!*\
  !*** ./src/app/packages/sidebar/sidebar/sidebar.component.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".profile_image_container {\n  background-color: #B2F34F !important; }\n\n.profile_information_container {\n  background-color: #B2F34F !important;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  font-weight: bold; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFja2FnZXMvc2lkZWJhci9zaWRlYmFyL0Q6XFx3b3JrXFxQcm9qZWN0c1xcYW5ndWxhcjJcXGFuZ3VsYXItbWF0ZXJpYWwvc3JjXFxhcHBcXHBhY2thZ2VzXFxzaWRlYmFyXFxzaWRlYmFyXFxzaWRlYmFyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0kscUNBQXNELEVBQ3pEOztBQUVEO0VBQ0kscUNBQXNEO0VBQ3RELGtCQUFpQjtFQUNqQixxQkFBb0I7RUFDcEIsa0JBQWlCLEVBQ3BCIiwiZmlsZSI6InNyYy9hcHAvcGFja2FnZXMvc2lkZWJhci9zaWRlYmFyL3NpZGViYXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIkcHJvZmlsZV9iYWNrZ3JvdW5kX2NvbG9yOiNCMkYzNEY7XHJcbi5wcm9maWxlX2ltYWdlX2NvbnRhaW5lciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkcHJvZmlsZV9iYWNrZ3JvdW5kX2NvbG9yICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5wcm9maWxlX2luZm9ybWF0aW9uX2NvbnRhaW5lciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkcHJvZmlsZV9iYWNrZ3JvdW5kX2NvbG9yICFpbXBvcnRhbnQ7XHJcbiAgICBwYWRkaW5nLXRvcDogMTBweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/packages/sidebar/sidebar/sidebar.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/packages/sidebar/sidebar/sidebar.component.ts ***!
  \***************************************************************/
/*! exports provided: SidebarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidebarComponent", function() { return SidebarComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core */ "./src/app/packages/core/index.ts");



var SidebarComponent = /** @class */ (function () {
    function SidebarComponent(coreService) {
        this.coreService = coreService;
    }
    SidebarComponent.prototype.ngOnInit = function () {
        // console.log(this.coreService.getVisibleRoutes());
        this.navigations = this.coreService.getVisibleRoutes();
    };
    SidebarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sidebar',
            template: __webpack_require__(/*! ./sidebar.component.html */ "./src/app/packages/sidebar/sidebar/sidebar.component.html"),
            styles: [__webpack_require__(/*! ./sidebar.component.scss */ "./src/app/packages/sidebar/sidebar/sidebar.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_core__WEBPACK_IMPORTED_MODULE_2__["CoreService"]])
    ], SidebarComponent);
    return SidebarComponent;
}());



/***/ }),

/***/ "./src/app/packages/toolbar/toolbar.module.ts":
/*!****************************************************!*\
  !*** ./src/app/packages/toolbar/toolbar.module.ts ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _toolbar_toolbar_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./toolbar/toolbar.component */ "./src/app/packages/toolbar/toolbar/toolbar.component.ts");







// import {  } from ;
var ToolbarModule = /** @class */ (function () {
    function ToolbarModule() {
    }
    ToolbarModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_toolbar_toolbar_component__WEBPACK_IMPORTED_MODULE_6__["ToolbarComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatToolbarModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_3__["MatMenuModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_4__["FlexLayoutModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"]
            ],
            exports: [_toolbar_toolbar_component__WEBPACK_IMPORTED_MODULE_6__["ToolbarComponent"]]
        })
    ], ToolbarModule);
    return ToolbarModule;
}());
/* harmony default export */ __webpack_exports__["default"] = (ToolbarModule);


/***/ }),

/***/ "./src/app/packages/toolbar/toolbar/toolbar.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/packages/toolbar/toolbar/toolbar.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-toolbar color=\"warn\">\r\n    <mat-toolbar-row fxLayout fxLayoutAlign='space-between center'>\r\n        <div>\r\n            <button mat-button (click)=\"ToggleSidebar(sidenav)\">\r\n        <mat-icon>menu</mat-icon>\r\n      </button>\r\n        </div>\r\n        <div *ngIf=\"coreService.getLoggedInUserStatus()\">\r\n            <button mat-button [matMenuTriggerFor]=\"menu\">\r\n        <mat-icon>more_vert</mat-icon>\r\n      </button>\r\n            <mat-menu #menu=\"matMenu\">\r\n                <button mat-menu-item (click)=\"logout()\">\r\n          Logout\r\n        </button>\r\n            </mat-menu>\r\n        </div>\r\n    </mat-toolbar-row>\r\n</mat-toolbar>"

/***/ }),

/***/ "./src/app/packages/toolbar/toolbar/toolbar.component.scss":
/*!*****************************************************************!*\
  !*** ./src/app/packages/toolbar/toolbar/toolbar.component.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhY2thZ2VzL3Rvb2xiYXIvdG9vbGJhci90b29sYmFyLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/packages/toolbar/toolbar/toolbar.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/packages/toolbar/toolbar/toolbar.component.ts ***!
  \***************************************************************/
/*! exports provided: ToolbarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolbarComponent", function() { return ToolbarComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../core */ "./src/app/packages/core/index.ts");





var ToolbarComponent = /** @class */ (function () {
    function ToolbarComponent(coreService, router) {
        this.coreService = coreService;
        this.router = router;
        this.themes = [
            {
                name: 'Gray',
                value: 'gray'
            }, {
                name: 'Purple',
                value: 'purple'
            }, {
                name: 'Pink',
                value: 'pink'
            }, {
                name: 'Indigo',
                value: 'indigo'
            }
        ];
        this.currentTheme = 'pink';
    }
    ToolbarComponent.prototype.ngOnInit = function () { };
    ToolbarComponent.prototype.ToggleSidebar = function (sidenav) {
        sidenav.toggle();
    };
    ToolbarComponent.prototype.ChangeTheme = function (theme) {
        this.currentTheme = theme;
        this
            .coreService
            .changeTheme
            .emit(theme);
    };
    ToolbarComponent.prototype.logout = function () {
        firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]()
            .signOut();
        this
            .router
            .navigate(['/login']);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ToolbarComponent.prototype, "sidenav", void 0);
    ToolbarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({ selector: 'app-toolbar', template: __webpack_require__(/*! ./toolbar.component.html */ "./src/app/packages/toolbar/toolbar/toolbar.component.html"), styles: [__webpack_require__(/*! ./toolbar.component.scss */ "./src/app/packages/toolbar/toolbar/toolbar.component.scss")] }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_core__WEBPACK_IMPORTED_MODULE_4__["CoreService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], ToolbarComponent);
    return ToolbarComponent;
}());



/***/ }),

/***/ "./src/app/routes.ts":
/*!***************************!*\
  !*** ./src/app/routes.ts ***!
  \***************************/
/*! exports provided: SiteRoute */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SiteRoute", function() { return SiteRoute; });
/* harmony import */ var _packages_guard_auth_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./packages/guard/auth.guard */ "./src/app/packages/guard/auth.guard.ts");

var SiteRoute = [
    {
        path: '',
        // redirectTo: '/list', pathMatch: 'full'
        loadChildren: './business/home/home.module#HomeModule',
        canActivate: [_packages_guard_auth_guard__WEBPACK_IMPORTED_MODULE_0__["AuthGuard"]],
    }, {
        path: 'about',
        loadChildren: './business/about/about.module#AboutModule',
        canActivate: [_packages_guard_auth_guard__WEBPACK_IMPORTED_MODULE_0__["AuthGuard"]],
        data: {
            MenuShow: true,
            MenuTitle: 'About',
            Route: '/about'
        }
    }, {
        path: 'contact',
        loadChildren: './business/contact/contact.module#ContactModule',
        canActivate: [_packages_guard_auth_guard__WEBPACK_IMPORTED_MODULE_0__["AuthGuard"]],
        data: {
            MenuShow: true,
            MenuTitle: 'Contact',
            Route: '/contact'
        }
    },
    // {
    //     path: 'list',
    //     loadChildren: './business/home/home.module#HomeModule',
    //     canActivate: [AuthGuard],
    //     data: {
    //         MenuShow: true,
    //     }
    // }, 
    {
        path: 'login',
        loadChildren: './packages/login/login.module#LoginModule',
        canActivate: [_packages_guard_auth_guard__WEBPACK_IMPORTED_MODULE_0__["AuthGuard"]],
        data: {
            MenuShow: false
        }
    }, {
        path: '404',
        loadChildren: './packages/page-not-found/page-not-found.module#PageNotFoundModule',
        data: {
            MenuShow: false
        }
    }, {
        path: '**',
        redirectTo: '/404'
    }
];



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\work\Projects\angular2\angular-material\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map