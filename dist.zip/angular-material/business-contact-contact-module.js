(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["business-contact-contact-module"],{

/***/ "./src/app/business/contact/contact.module.ts":
/*!****************************************************!*\
  !*** ./src/app/business/contact/contact.module.ts ***!
  \****************************************************/
/*! exports provided: ContactModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactModule", function() { return ContactModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _contact_contact_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./contact/contact.component */ "./src/app/business/contact/contact/contact.component.ts");





var routes = [
    {
        path: '',
        component: _contact_contact_component__WEBPACK_IMPORTED_MODULE_4__["ContactComponent"],
    }
];
var ContactModule = /** @class */ (function () {
    function ContactModule() {
    }
    ContactModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_contact_contact_component__WEBPACK_IMPORTED_MODULE_4__["ContactComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes),
            ]
        })
    ], ContactModule);
    return ContactModule;
}());



/***/ }),

/***/ "./src/app/business/contact/contact/contact.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/business/contact/contact/contact.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  contact works!\n</p>\n"

/***/ }),

/***/ "./src/app/business/contact/contact/contact.component.scss":
/*!*****************************************************************!*\
  !*** ./src/app/business/contact/contact/contact.component.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2J1c2luZXNzL2NvbnRhY3QvY29udGFjdC9jb250YWN0LmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/business/contact/contact/contact.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/business/contact/contact/contact.component.ts ***!
  \***************************************************************/
/*! exports provided: ContactComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactComponent", function() { return ContactComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _contact__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./contact */ "./src/app/business/contact/contact/contact.ts");



var ContactComponent = /** @class */ (function () {
    function ContactComponent() {
    }
    ContactComponent.prototype.ngOnInit = function () {
        // let contact = new Contact();
        // contact.sayHi();
        // contact.settings={
        //   name:'updated',
        //   email:'updatd'
        // };
        // contact.sayHi();
        // console.log(Contact.Pi);
        // console.log(Contact.calCPi(3));
        console.log(_contact__WEBPACK_IMPORTED_MODULE_2__["default"].calCPi(2));
        // contact.greeting = 'Ulala test';
        // console.log(contact.greeting);
    };
    ContactComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-contact',
            template: __webpack_require__(/*! ./contact.component.html */ "./src/app/business/contact/contact/contact.component.html"),
            styles: [__webpack_require__(/*! ./contact.component.scss */ "./src/app/business/contact/contact/contact.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ContactComponent);
    return ContactComponent;
}());



/***/ }),

/***/ "./src/app/business/contact/contact/contact.ts":
/*!*****************************************************!*\
  !*** ./src/app/business/contact/contact/contact.ts ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var Contact = /** @class */ (function () {
    function Contact() {
        this._settings = {
            name: 'hello',
            email: 'world'
        };
        this._greeting = 'default';
        // console.log(this._greeting);
    }
    Object.defineProperty(Contact.prototype, "greeting", {
        get: function () {
            return this._greeting;
        },
        set: function (value) {
            // this._settings=value;
            if (value.length > 3) {
                this._greeting = value;
            }
            else {
                this._greeting = "Hello world";
            }
        },
        enumerable: true,
        configurable: true
    });
    Contact.calCPi = function (dimension) {
        return this.Pi * dimension;
    };
    Contact.prototype.sayHi = function () {
        debugger;
        console.log(this._settings);
    };
    Contact.Pi = 3.1416;
    return Contact;
}());
/* harmony default export */ __webpack_exports__["default"] = (Contact);


/***/ })

}]);
//# sourceMappingURL=business-contact-contact-module.js.map